let pageReadyTime;

function setCookie(cookieName, cookieValue) {
    document.cookie = cookieName + "=" + cookieValue + ";";
}

function getCookie(cookieName) {
    let name = cookieName + "=";
    let cookieArray = document.cookie.split(';');

    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i].trim();
        if (cookie.indexOf(name) === 0) {
            return cookie.substring(name.length, cookie.length);
        }
    }
    return null;
}

function deleteCookie(cookieName) {
    document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
}

function validatePostalCode(inputValue) {
    const postalcodePattern = /^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$/;
    return postalcodePattern.test(inputValue);
}

function validateForm() {
    let fullName = $("#fullName").val();
    let email = $("#email").val();
    let password = $("#password").val();
    let date = $("#date").val();
    let postalCode = $("#postalCode").val();

    let isValidFullName = validateNoDigits(fullName);
    let isValidEmail = validateEmail(email);
    let isValidPassword = password.length >= 6; // Example: Check password length
    let isValidDate = date !== "";
    let isValidPostalCode = validatePostalCode(postalCode);

    return isValidFullName && isValidEmail && isValidPassword && isValidDate && isValidPostalCode;
}

function getTimeSpent() {
    let currentTime = new Date();
    let timeDifference = Math.floor((currentTime - pageReadyTime) / 1000);
    return timeDifference;
}

$(document).ready(function() {
    pageReadyTime = new Date();
    let maxDate = pageReadyTime.toISOString().substring(0, 10);

    $("small").hide();

    $('#date').prop('max', maxDate);

    $("#postalCode").on("keyup", function() {
        let inputValue = $(this).val().toUpperCase();
        let isValid = validatePostalCode(inputValue);
        let smallText = "#s-" + $(this).attr("id");

        if (isValid) {
            $(this).css("background-color", "#99FFCC");
            $(smallText).hide();
        } else {
            $(this).css("background-color", "#FF9999");
            $(smallText).show();
        }
    });

    $("#userForm").submit(function(event) {
        event.preventDefault(); // Prevent form submission

        let isValid = validateForm();
        if (!isValid) {
            return;
        }

        let minutes = Math.floor(getTimeSpent() / 60);
        let seconds = getTimeSpent() % 60;
        let timeSpentString = minutes + "m" + seconds + "s";

        // Save form data in a cookie
        const formData = {
            fullName: $("#fullName").val(),
            email: $("#email").val(),
            password: $("#password").val(),
            date: $("#date").val(),
            postalCode: $("#postalCode").val().toUpperCase(),
            description: $("#description").val() // Added description field
        };
        setCookie('formData', JSON.stringify(formData)); // JSON.stringify to store the object in the cookie

        // Save fill time in a cookie
        setCookie('fillTime', timeSpentString);

        // Redirect to the second page after submitting the form
        window.location.href = 'project2-second.html';
    });
});